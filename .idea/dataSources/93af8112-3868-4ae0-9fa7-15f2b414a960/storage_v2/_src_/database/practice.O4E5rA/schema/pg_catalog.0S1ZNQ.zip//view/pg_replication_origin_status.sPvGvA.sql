create view pg_replication_origin_status(local_id, external_id, remote_lsn, local_lsn) as
SELECT pg_show_replication_origin_status.local_id,
       pg_show_replication_origin_status.external_id,
       pg_show_replication_origin_status.remote_lsn,
       pg_show_replication_origin_status.local_lsn
FROM pg_show_replication_origin_status() pg_show_replication_origin_status(local_id, external_id, remote_lsn, local_lsn);

alter table pg_replication_origin_status
    owner to postgres;

